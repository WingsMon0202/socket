#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 12345
#define BUFFER_SIZE 1024
#define USERNAME_LEN 32

int sockfd;

void *receive_handler(void *arg) {
    char buffer[BUFFER_SIZE];
    int len;

    while ((len = recv(sockfd, buffer, sizeof(buffer) - 1, 0)) > 0) {
        buffer[len] = '\0';
        printf("\r%s\n> ", buffer);
        fflush(stdout);
    }

    printf("\nDisconnected from server.\n");
    exit(EXIT_FAILURE);
}

int main() {
    struct sockaddr_in server_addr;
    char message[BUFFER_SIZE];
    char username[USERNAME_LEN];
    char password[USERNAME_LEN];

    printf("Enter your username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';

    printf("Enter your password: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = '\0';

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect failed");
        exit(EXIT_FAILURE);
    }

    char credentials[BUFFER_SIZE];
    snprintf(credentials, sizeof(credentials), "%s:%s", username, password);
    send(sockfd, credentials, strlen(credentials), 0);

    char response[BUFFER_SIZE];
    int len = recv(sockfd, response, sizeof(response) - 1, 0);
    if (len <= 0) {
        printf("Server closed connection.\n");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    response[len] = '\0';

    if (strcmp(response, "AUTH_SUCCESS") != 0) {
        printf("Login failed: %s\n", response);
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to chat server as '%s'.\n", username);

    pthread_t recv_thread;
    pthread_create(&recv_thread, NULL, receive_handler, NULL);

    while (1) {
        printf("> ");
        if (fgets(message, sizeof(message), stdin) == NULL)
            break;

        send(sockfd, message, strlen(message), 0);
    }

    close(sockfd);
    return 0;
}

